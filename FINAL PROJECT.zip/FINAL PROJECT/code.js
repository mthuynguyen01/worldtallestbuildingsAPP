//START THE PROGRAM
onEvent("startButton", "click", function( ) {
  setScreen("2OPTIONSSCREEN");
});
// GET DATA FROM THE DATA TABLE
var nameList = getColumn("World's Tallest Buildings", "Name");
var countryList = getColumn("World's Tallest Buildings", "Country");
var yearsList = getColumn("World's Tallest Buildings", "Year opened");
var cityList = getColumn("World's Tallest Buildings", "City");
var ranklist = getColumn("World's Tallest Buildings", "Rank");
var heightList = getColumn("World's Tallest Buildings", "Height in feet");
var imageList = getColumn("World's Tallest Buildings", "Image");
var selectedcity, selectedName, selectedRank, selectedYears, selectedHeight, selectedImage, selectedCountry;
UpdateSelectionCity();
timeUpdate();
//ENDSCREEN DISPLAY
onEvent("locationNextbutton", "click", function( ) {
  selectedcity = getText("cityDropdown");
  resultLocation();
});
onEvent("timeNextbutton", "click", function( ) {
  selectedYears = getText("yearsoutputHidden");
  resultYears();
});

// CLICK TO NEXT SCREEN
onEvent("locationbutton", "click", function( ) {
  setScreen("SCREENLOCATION");
});
onEvent("yearbutton", "click", function( ) {
  setScreen("SCREENTIME");
});
onEvent("timeNextbutton", "click", function( ) {
  setScreen("ENDSCREEN");
});
onEvent("locationNextbutton", "click", function( ) {
  setScreen("ENDSCREEN");
});
onEvent("back", "click", function( ) {
  setScreen("2OPTIONSSCREEN");
});
//City selection 
function UpdateSelectionCity() {
  var countrySelection = getText("countrySelect");
  if (countrySelection == "China") {
    setProperty("cityDropdown", "options", filteredCC);
  } else if (countrySelection == "Kuwait") {
    setProperty("cityDropdown", "options", [cityList[33]]);
  } else if (countrySelection == "United States") {
    setProperty("cityDropdown", "options", [(cityList[5]), [(cityList[21])]]);
  } else if (countrySelection == "Vietnam") {
    setProperty("cityDropdown", "options", [cityList[14]]);
  } else if (countrySelection == "United Arab Emirates") {
    setProperty("cityDropdown", "options", [(cityList[0]), [(cityList[47])]]);
  } else if (countrySelection == "South Korea") {
    setProperty("cityDropdown", "options", [(cityList[4]), [(cityList[35])]]);
  } else if ((countrySelection == "Taiwan")) {
    setProperty("cityDropdown", "options", [cityList[9]]);
  } else if (countrySelection == "Russia") {
    setProperty("cityDropdown", "options", [(cityList[13]), [(cityList[52])]]);
  } else if (countrySelection == "Saudi Arabia") {
    setProperty("cityDropdown", "options", [(cityList[2]), [(cityList[43])]]);
  } else if (countrySelection == "Malaysia") {
    setProperty("cityDropdown", "options", [cityList[16]]);
  }
}

//REDUCE DATA FOR TIME OPTION
function timeUpdate() {
  onEvent("submibutton", "click", function( ) {
    var Timechoice = getText("yearSelect");
    var year = yearsList[0];
    var name = [];
    for (var i = 0; i < yearsList.length; i++) {
      if (Timechoice == "Oldest" && yearsList[i] < year) {
       year = yearsList[i];
       name = nameList[i];
      } else if ((Timechoice == "Newest" && yearsList[i] > year)) {
      year = yearsList[i];
      name = nameList[i];
      }
    }
    setText("yearsoutputHidden", year);
    setText("outputTime", ("The year is " + year + "\n" + "Building: ") + name);
  });
}

//NEW COUNTRY FILTERED LIST
var filteredCountry = [];
newCountryList();
function newCountryList() {
  for (var i = 0; i < countryList.length - 62; i++) {
    if (countryList[i] != "China") {
      appendItem(filteredCountry, countryList[i]);
    }
  }
  for (var j = 12; j < countryList.length - 56; j++) {
    if (countryList[j] != "United States") {
      appendItem(filteredCountry, countryList[j]);
    }
  }
  if (countryList[33] == "Kuwait") {
    appendItem(filteredCountry, countryList[33]);
  }
}
//Update list to drop down menu for country and city
setProperty("countrySelect", "options", filteredCountry);
onEvent("countrySelect", "change", function( ) {
  UpdateSelectionCity();
});
//CityFiltered from country "China"
var chinaCity = [];
var filteredCC = [];
cityfilter();
function cityfilter() {
  chinaCity = [];
  filteredCC = [];
  for (var i = 0; i < countryList.length; i++) {
    if (countryList[i] == "China") {
      appendItem(chinaCity, cityList[i]);
    }
  }
  for (var j = 1; j < chinaCity.length - 26; j++) {
    if (chinaCity[j] != "Shanghai") {
      appendItem(filteredCC, chinaCity[j]);
    }
  }
  for (var o = 13; o < chinaCity.length - 18; o++) {
    if (chinaCity[o] != "Shanghai" && chinaCity[o] != "Hong Kong") {
      appendItem(filteredCC, chinaCity[o]);
    }
  }
  for (var t = 25; t < chinaCity.length-9; t++) {
    if (chinaCity[t] != "Hong Kong") {
      appendItem(filteredCC, chinaCity[t]);
    }
  }
  for (var e = 32; e < chinaCity.length - 2; e++) {
    if (chinaCity[e] != "Shenyang") {
      appendItem(filteredCC, chinaCity[e]);
    }
  }
  appendItem(filteredCC, chinaCity[27]);
  appendItem(filteredCC, chinaCity[12]);
  appendItem(filteredCC, chinaCity[35]);
}

//SET INFORMATION FUNCTIONS

function resultLocation() {
  for (var i = 0; i < cityList.length; i++) {
    var city = cityList[i];
    if (city == selectedcity) {
      selectedName = nameList[i];
      selectedRank = ranklist[i];
      selectedYears = yearsList[i];
      selectedHeight = heightList[i];
      selectedImage = imageList[i];
      selectedCountry = countryList[i];
      Display();
    }
  }
}
function resultYears() {
  for (var i = 0; i < yearsList.length; i++) {
    var yearopen = yearsList[i];
    if (yearopen == selectedYears) {
      selectedcity = cityList[i];
      selectedName = nameList[i];
      selectedRank = ranklist[i];
      selectedHeight = heightList[i];
      selectedImage = imageList[i];
      selectedCountry = countryList[i];
      Display();
    }
  }
}
function Display() {
  setText("Country", "Country: " + selectedCountry);
  setText("NameBD", "Name: " + selectedName);
  setText("City", "City: " + selectedcity);
  setText("Yearopened", "Year opened: " + selectedYears);
  setText("Rank", "Rank: " + selectedRank);
  setText("Height", "Height: " + selectedHeight);
  setImageURL("imageoutput", selectedImage);
}
